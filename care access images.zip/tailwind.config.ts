import type { Config } from 'tailwindcss'

const config: Config = {
  content: [
    './src/pages/**/*.{js,ts,jsx,tsx,mdx}',
    './src/components/**/*.{js,ts,jsx,tsx,mdx}',
    './src/app/**/*.{js,ts,jsx,tsx,mdx}',
  ],
  theme: {
    extend: {
      colors: {
        navy: {
          DEFAULT: '#014381',
          50: '#e6eef9',
          100: '#b3ccee',
          200: '#80aae3',
          300: '#4d88d8',
          400: '#2066cd',
          500: '#014381',
          600: '#013872',
          700: '#012d5f',
          800: '#01224c',
          900: '#001739',
        },
        teal: {
          DEFAULT: '#027A65',
          50: '#e0f5f2',
          100: '#b3e6df',
          200: '#80d6cc',
          300: '#4dc6b9',
          400: '#27b9a9',
          500: '#027A65',
          600: '#026858',
          700: '#025549',
          800: '#01433b',
          900: '#013128',
        },
        green: {
          DEFAULT: '#499A31',
          50: '#eef8ea',
          100: '#ceecbf',
          200: '#aee094',
          300: '#8ed469',
          400: '#74cc4f',
          500: '#499A31',
          600: '#3d8429',
          700: '#316c21',
          800: '#255419',
          900: '#193c11',
        },
        orange: {
          DEFAULT: '#F18316',
          50: '#fef5e7',
          100: '#fce3b9',
          200: '#fad08a',
          300: '#f8bd5b',
          400: '#f6ae37',
          500: '#F18316',
          600: '#d4720a',
          700: '#b86104',
          800: '#9c5000',
          900: '#803f00',
        },
      },
      fontFamily: {
        sans: ['Marcellus', 'Georgia', 'serif'],
        display: ['Marcellus', 'Georgia', 'serif'],
      },
      animation: {
        'fade-in': 'fadeIn 0.6s ease-out forwards',
        'slide-up': 'slideUp 0.6s ease-out forwards',
        'slide-in-left': 'slideInLeft 0.6s ease-out forwards',
        'slide-in-right': 'slideInRight 0.6s ease-out forwards',
        'float': 'float 3s ease-in-out infinite',
        'pulse-slow': 'pulse 3s ease-in-out infinite',
      },
      keyframes: {
        fadeIn: {
          '0%': { opacity: '0' },
          '100%': { opacity: '1' },
        },
        slideUp: {
          '0%': { opacity: '0', transform: 'translateY(30px)' },
          '100%': { opacity: '1', transform: 'translateY(0)' },
        },
        slideInLeft: {
          '0%': { opacity: '0', transform: 'translateX(-30px)' },
          '100%': { opacity: '1', transform: 'translateX(0)' },
        },
        slideInRight: {
          '0%': { opacity: '0', transform: 'translateX(30px)' },
          '100%': { opacity: '1', transform: 'translateX(0)' },
        },
        float: {
          '0%, 100%': { transform: 'translateY(0px)' },
          '50%': { transform: 'translateY(-10px)' },
        },
      },
      backgroundImage: {
        'gradient-radial': 'radial-gradient(var(--tw-gradient-stops))',
        'gradient-conic': 'conic-gradient(from 180deg at 50% 50%, var(--tw-gradient-stops))',
      },
      boxShadow: {
        'soft': '0 2px 20px rgba(1, 67, 129, 0.08)',
        'medium': '0 4px 30px rgba(1, 67, 129, 0.12)',
        'large': '0 8px 40px rgba(1, 67, 129, 0.16)',
        'teal': '0 4px 20px rgba(2, 122, 101, 0.25)',
        'navy': '0 4px 20px rgba(1, 67, 129, 0.25)',
      },
    },
  },
  plugins: [],
}

export default config
