'use client'

import { useState, useEffect, useRef } from 'react'
import Link from 'next/link'
import Image from 'next/image'
import { usePathname } from 'next/navigation'
import { Menu, X, ChevronDown, User, LogIn, UserPlus } from 'lucide-react'
import { cn } from '@/lib/utils'

const navLinks = [
  { href: '/', label: 'Home' },
  { href: '/about', label: 'About Us' },
  { href: '/services', label: 'Services' },
  { href: '/become-a-member', label: 'Become a Member' },
  { href: '/contact', label: 'Contact' },
]

export default function Navbar() {
  const [isScrolled, setIsScrolled] = useState(false)
  const [mobileOpen, setMobileOpen] = useState(false)
  const [authOpen, setAuthOpen] = useState(false)
  const pathname = usePathname()
  const authRef = useRef<HTMLDivElement>(null)

  useEffect(() => {
    const handleScroll = () => setIsScrolled(window.scrollY > 20)
    window.addEventListener('scroll', handleScroll, { passive: true })
    return () => window.removeEventListener('scroll', handleScroll)
  }, [])

  useEffect(() => {
    const handleClickOutside = (e: MouseEvent) => {
      if (authRef.current && !authRef.current.contains(e.target as Node)) {
        setAuthOpen(false)
      }
    }
    document.addEventListener('mousedown', handleClickOutside)
    return () => document.removeEventListener('mousedown', handleClickOutside)
  }, [])

  useEffect(() => {
    setMobileOpen(false)
  }, [pathname])

  useEffect(() => {
    document.body.style.overflow = mobileOpen ? 'hidden' : ''
    return () => { document.body.style.overflow = '' }
  }, [mobileOpen])

  return (
    <>
      <header
        className={cn(
          'fixed top-0 left-0 right-0 z-50 transition-all duration-300 bg-white border-b border-gray-100',
          isScrolled ? 'shadow-soft' : 'shadow-none'
        )}
      >
        <div className="container-max">
          <div className="flex items-center justify-between h-16 md:h-20">
            {/* Logo */}
            <Link href="/" className="flex-shrink-0" aria-label="Care Access Nigeria — Home">
              <Image
                src="/logo.png"
                alt="Care Access Nigeria"
                width={1187}
                height={540}
                className="h-16 w-auto object-contain logo-animate"
                priority
              />
            </Link>

            {/* Desktop Nav */}
            <nav className="hidden lg:flex items-center gap-1">
              {navLinks.map((link) => {
                const isActive = pathname === link.href
                return (
                  <Link
                    key={link.href}
                    href={link.href}
                    className={cn(
                      'relative px-4 py-2 text-sm font-medium transition-colors duration-200 group',
                      isActive ? 'text-teal' : 'text-gray-500 hover:text-navy'
                    )}
                  >
                    {link.label}

                    {/* Animated underline */}
                    <span
                      className={cn(
                        'absolute bottom-0 left-0 h-0.5 rounded-full transition-all duration-300 ease-out bg-teal',
                        isActive
                          ? 'w-full'
                          : 'w-0 group-hover:w-full group-hover:bg-navy/40'
                      )}
                    />
                  </Link>
                )
              })}
            </nav>

            {/* Right side */}
            <div className="flex items-center gap-3">
              {/* Auth dropdown */}
              <div className="hidden md:block relative" ref={authRef}>
                <button
                  onClick={() => setAuthOpen(!authOpen)}
                  onMouseEnter={() => setAuthOpen(true)}
                  className="flex items-center gap-2 px-4 py-2 rounded-lg text-sm font-medium transition-all duration-200 border border-gray-200 text-gray-600 hover:border-navy hover:text-navy bg-white"
                  aria-expanded={authOpen}
                >
                  <User size={15} />
                  <span>Account</span>
                  <ChevronDown
                    size={14}
                    className={cn('transition-transform duration-200', authOpen && 'rotate-180')}
                  />
                </button>

                {authOpen && (
                  <div
                    className="absolute right-0 top-full mt-2 w-48 bg-white rounded-xl shadow-large border border-gray-100 overflow-hidden"
                    onMouseLeave={() => setAuthOpen(false)}
                  >
                    <a
                      href="https://careaccess.ng/login"
                      className="flex items-center gap-3 px-4 py-3.5 text-sm text-gray-700 hover:bg-teal/5 hover:text-teal transition-colors duration-150 border-b border-gray-50"
                    >
                      <LogIn size={15} className="text-teal" />
                      <span className="font-medium">Login</span>
                    </a>
                    <Link
                      href="/become-a-member"
                      className="flex items-center gap-3 px-4 py-3.5 text-sm text-gray-700 hover:bg-navy/5 hover:text-navy transition-colors duration-150"
                    >
                      <UserPlus size={15} className="text-navy" />
                      <span className="font-medium">Register</span>
                    </Link>
                  </div>
                )}
              </div>

              {/* CTA Button */}
              <Link
                href="/become-a-member"
                className="hidden md:inline-flex items-center gap-2 px-5 py-2.5 rounded-lg text-sm font-semibold transition-all duration-300 bg-teal text-white hover:bg-teal-600 shadow-teal"
              >
                Become a Member
              </Link>

              {/* Mobile menu toggle */}
              <button
                onClick={() => setMobileOpen(!mobileOpen)}
                className="lg:hidden p-2 rounded-lg transition-colors duration-200 text-gray-600 hover:bg-gray-100"
                aria-label={mobileOpen ? 'Close menu' : 'Open menu'}
              >
                {mobileOpen ? <X size={22} /> : <Menu size={22} />}
              </button>
            </div>
          </div>
        </div>
      </header>

      {/* Mobile Menu */}
      <div
        className={cn(
          'fixed inset-0 z-40 lg:hidden transition-all duration-300',
          mobileOpen ? 'opacity-100 pointer-events-auto' : 'opacity-0 pointer-events-none'
        )}
      >
        {/* Backdrop */}
        <div
          className="absolute inset-0 bg-navy/60 backdrop-blur-sm"
          onClick={() => setMobileOpen(false)}
        />

        {/* Panel */}
        <div
          className={cn(
            'absolute right-0 top-0 bottom-0 w-72 bg-white shadow-2xl transition-transform duration-300 flex flex-col',
            mobileOpen ? 'translate-x-0' : 'translate-x-full'
          )}
        >
          <div className="flex items-center justify-between p-5 border-b border-gray-100">
            <div className="flex items-center">
              <Image
                src="/logo.png"
                alt="Care Access Nigeria"
                width={1187}
                height={540}
                className="h-10 w-auto object-contain"
              />
            </div>
            <button
              onClick={() => setMobileOpen(false)}
              className="p-2 rounded-lg text-gray-400 hover:text-gray-600 hover:bg-gray-100"
            >
              <X size={20} />
            </button>
          </div>

          <nav className="flex-1 py-3 overflow-y-auto">
            {navLinks.map((link) => {
              const isActive = pathname === link.href
              return (
                <Link
                  key={link.href}
                  href={link.href}
                  className={cn(
                    'relative flex items-center gap-3 mx-3 px-4 py-3.5 my-0.5 rounded-xl text-sm font-medium transition-all duration-200',
                    isActive
                      ? 'text-teal bg-teal/8 shadow-[inset_0_1px_0_rgba(2,122,101,0.15),0_1px_3px_rgba(2,122,101,0.08)]'
                      : 'text-gray-600 hover:text-navy hover:bg-gray-50'
                  )}
                >
                  {/* Active left bar */}
                  {isActive && (
                    <span className="absolute left-0 top-1/2 -translate-y-1/2 w-1 h-6 rounded-r-full bg-teal" />
                  )}
                  <span className={cn(
                    'w-2 h-2 rounded-full flex-shrink-0 transition-all duration-200',
                    isActive ? 'bg-teal scale-110' : 'bg-gray-200'
                  )} />
                  <span>{link.label}</span>
                  {isActive && (
                    <span className="ml-auto text-teal/50">
                      <svg width="14" height="14" viewBox="0 0 14 14" fill="none">
                        <path d="M5 3l4 4-4 4" stroke="currentColor" strokeWidth="1.5" strokeLinecap="round" strokeLinejoin="round"/>
                      </svg>
                    </span>
                  )}
                </Link>
              )
            })}
          </nav>

          <div className="p-5 space-y-3 border-t border-gray-100">
            <a
              href="https://careaccess.ng/login"
              className="flex items-center justify-center gap-2 w-full py-3 border-2 border-navy text-navy rounded-lg text-sm font-semibold hover:bg-navy hover:text-white transition-all duration-200"
            >
              <LogIn size={15} /> Login
            </a>
            <Link
              href="/become-a-member"
              className="flex items-center justify-center gap-2 w-full py-3 bg-teal text-white rounded-lg text-sm font-semibold hover:bg-teal-600 transition-all duration-200"
            >
              <UserPlus size={15} /> Become a Member
            </Link>
          </div>
        </div>
      </div>
    </>
  )
}
