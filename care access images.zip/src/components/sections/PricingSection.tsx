'use client'

import { useState, useEffect, useCallback } from 'react'
import Link from 'next/link'
import AnimatedSection from '@/components/ui/AnimatedSection'
import MembershipForm from '@/components/sections/MembershipForm'
import { CheckCircle2, Star, X } from 'lucide-react'

const plans = [
  {
    name: 'Personal Care',
    price: '25,000',
    badge: 'Most Popular',
    planKey: 'personal',
    description: 'Reliable, continuous care for individuals who want a dedicated team.',
    features: [
      'Speak to a doctor when you need to',
      '24/7 clinical advice',
      'Same-day or next-day appointments',
      'Full medical record & continuity of care',
      'Prescription & medication support',
      'Specialist referrals & care guidance',
    ],
    cta: 'Choose Personal Care',
    colorScheme: 'teal' as const,
  },
  {
    name: 'Extended Care',
    price: '45,000',
    badge: 'Premium',
    planKey: 'extended',
    description: 'For those who need more frequent support or managing ongoing conditions.',
    features: [
      'Everything in Personal Care',
      'More frequent doctor consultations',
      'Ongoing chronic condition management',
      'Proactive clinical check-ins',
      '1 home nurse visit per month',
      'Priority response',
    ],
    cta: 'Choose Extended Care',
    colorScheme: 'light' as const,
  },
  {
    name: 'Family Care',
    price: '85,000',
    badge: 'Best Value',
    planKey: 'family',
    description: 'One trusted care team for your whole household — up to 4 people.',
    features: [
      'Covers up to 4 family members',
      'Shared doctor access for all members',
      '24/7 clinical advice for the family',
      'Family medical records',
      "Adult and children's care",
      '1 home nurse visit per month',
    ],
    cta: 'Choose Family Care',
    colorScheme: 'navy' as const,
  },
]

const badgeColors: Record<string, string> = {
  'Most Popular': 'bg-orange',
  Premium: 'bg-teal',
  'Best Value': 'bg-navy',
}

const planAccentColors: Record<string, string> = {
  teal: 'border-t-4 border-teal',
  light: 'border-t-4 border-gray-200',
  navy: 'border-t-4 border-navy',
}

export default function PricingSection() {
  const [modalOpen, setModalOpen] = useState(false)
  const [selectedPlan, setSelectedPlan] = useState('')
  const [selectedPlanName, setSelectedPlanName] = useState('')

  const openModal = useCallback((planKey: string, planName: string) => {
    setSelectedPlan(planKey)
    setSelectedPlanName(planName)
    setModalOpen(true)
  }, [])

  const closeModal = useCallback(() => {
    setModalOpen(false)
  }, [])

  // Lock body scroll when modal open
  useEffect(() => {
    document.body.style.overflow = modalOpen ? 'hidden' : ''
    return () => { document.body.style.overflow = '' }
  }, [modalOpen])

  // Close on Escape key
  useEffect(() => {
    const onKey = (e: KeyboardEvent) => { if (e.key === 'Escape') closeModal() }
    window.addEventListener('keydown', onKey)
    return () => window.removeEventListener('keydown', onKey)
  }, [closeModal])

  return (
    <>
      {/* Plan Cards */}
      <section className="section-padding bg-white" aria-labelledby="plans-heading">
        <div className="container-max">
          <AnimatedSection className="text-center mb-14">
            <div className="section-tag bg-orange/10 text-orange mx-auto mb-4">Membership Plans</div>
            <h2 id="plans-heading" className="text-3xl md:text-4xl font-extrabold text-navy mb-4">
              Choose a plan that{' '}
              <span className="text-teal">works for you</span>
            </h2>
            <p className="text-base text-gray-500 max-w-lg mx-auto">
              Simple, transparent pricing. No hidden costs, no lock-in. Cancel before your next billing date.
            </p>
          </AnimatedSection>

          <div className="grid md:grid-cols-3 gap-6 lg:gap-8 items-center">
            {plans.map(({ name, price, badge, planKey, description, features, cta, colorScheme }, i) => (
              <AnimatedSection key={name} delay={i * 100} animation="fade-up">
                <div
                  className={`relative rounded-2xl p-7 h-full flex flex-col transition-all duration-300 cursor-pointer group hover:-translate-y-2 hover:shadow-large ${
                    colorScheme === 'teal'
                      ? 'bg-teal text-white shadow-teal scale-105 z-10'
                      : colorScheme === 'navy'
                      ? 'bg-navy text-white shadow-navy'
                      : 'bg-white border border-gray-100 shadow-soft'
                  }`}
                  onClick={() => openModal(planKey, name)}
                  role="button"
                  tabIndex={0}
                  onKeyDown={(e) => e.key === 'Enter' && openModal(planKey, name)}
                  aria-label={`Select ${name} plan`}
                >
                  {/* Badge */}
                  <div className="absolute -top-3.5 left-1/2 -translate-x-1/2 whitespace-nowrap">
                    <div
                      className={`flex items-center gap-1.5 px-4 py-1.5 text-white text-xs font-bold rounded-full shadow-lg ${badgeColors[badge]}`}
                    >
                      <Star size={10} fill="currentColor" />
                      {badge}
                    </div>
                  </div>

                  <div className="mb-5 pt-2">
                    <h3
                      className={`text-lg font-bold mb-1 ${
                        colorScheme === 'light' ? 'text-navy' : 'text-white'
                      }`}
                    >
                      {name}
                    </h3>
                    <p
                      className={`text-sm leading-relaxed ${
                        colorScheme === 'teal' || colorScheme === 'navy'
                          ? 'text-white/70'
                          : 'text-gray-500'
                      }`}
                    >
                      {description}
                    </p>
                  </div>

                  <div className="mb-6 pb-6 border-b border-current/10">
                    <div className="flex items-end gap-1">
                      <span
                        className={`text-sm font-medium mb-1.5 ${
                          colorScheme === 'teal' || colorScheme === 'navy'
                            ? 'text-white/70'
                            : 'text-gray-400'
                        }`}
                      >
                        ₦
                      </span>
                      <span className="text-4xl font-extrabold">{price}</span>
                      <span
                        className={`text-sm mb-1.5 ${
                          colorScheme === 'teal' || colorScheme === 'navy'
                            ? 'text-white/70'
                            : 'text-gray-400'
                        }`}
                      >
                        /month
                      </span>
                    </div>
                    <p
                      className={`text-xs mt-1 ${
                        colorScheme === 'teal' || colorScheme === 'navy'
                          ? 'text-white/50'
                          : 'text-gray-400'
                      }`}
                    >
                      No lock-in. Cancel anytime.
                    </p>
                  </div>

                  <ul className="space-y-3 flex-1 mb-7">
                    {features.map((feature) => (
                      <li key={feature} className="flex items-start gap-2.5">
                        <CheckCircle2
                          size={15}
                          className={`flex-shrink-0 mt-0.5 ${
                            colorScheme === 'teal'
                              ? 'text-white'
                              : colorScheme === 'navy'
                              ? 'text-teal-300'
                              : 'text-teal'
                          }`}
                        />
                        <span
                          className={`text-sm ${
                            colorScheme === 'teal' || colorScheme === 'navy'
                              ? 'text-white/80'
                              : 'text-gray-600'
                          }`}
                        >
                          {feature}
                        </span>
                      </li>
                    ))}
                  </ul>

                  {/* CTA button */}
                  <div
                    className={`w-full py-3.5 rounded-xl font-semibold text-sm text-center transition-all duration-200 ${
                      colorScheme === 'teal'
                        ? 'bg-white text-teal group-hover:bg-gray-50'
                        : colorScheme === 'navy'
                        ? 'bg-teal text-white group-hover:bg-teal-600'
                        : 'bg-navy text-white group-hover:bg-navy/90'
                    }`}
                  >
                    {cta}
                  </div>
                </div>
              </AnimatedSection>
            ))}
          </div>

          <AnimatedSection className="text-center mt-10">
            <p className="text-xs text-gray-400">
              Need occasional care instead?{' '}
              <Link href="/contact" className="text-teal underline underline-offset-2">
                Book a pay-as-you-go consultation (₦8,000)
              </Link>
            </p>
          </AnimatedSection>
        </div>
      </section>

      {/* Modal Overlay */}
      {modalOpen && (
        <div
          className="fixed inset-0 z-[60] flex items-end sm:items-center justify-center p-0 sm:p-4"
          role="dialog"
          aria-modal="true"
          aria-label="Membership sign-up form"
        >
          {/* Backdrop */}
          <div
            className="absolute inset-0 bg-navy/70 backdrop-blur-sm"
            onClick={closeModal}
          />

          {/* Modal panel */}
          <div className="relative z-10 w-full sm:max-w-xl bg-white sm:rounded-3xl shadow-2xl flex flex-col max-h-[95vh] sm:max-h-[90vh] rounded-t-3xl animate-slide-up">

            {/* Modal header */}
            <div className="flex items-center justify-between px-7 pt-6 pb-4 border-b border-gray-100 flex-shrink-0">
              <div>
                <p className="text-xs font-semibold text-teal uppercase tracking-widest mb-0.5">
                  You selected
                </p>
                <h2 className="text-xl font-extrabold text-navy">{selectedPlanName}</h2>
              </div>
              <button
                onClick={closeModal}
                className="w-9 h-9 rounded-xl bg-gray-100 flex items-center justify-center text-gray-500 hover:bg-gray-200 hover:text-navy transition-all duration-200 flex-shrink-0"
                aria-label="Close"
              >
                <X size={18} />
              </button>
            </div>

            {/* Scrollable form area */}
            <div className="overflow-y-auto flex-1 px-7 py-6">
              <MembershipForm
                key={selectedPlan}
                defaultPlan={selectedPlan}
                onSuccess={closeModal}
              />
            </div>
          </div>
        </div>
      )}
    </>
  )
}
