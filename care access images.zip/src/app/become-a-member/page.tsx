import type { Metadata } from 'next'
import Image from 'next/image'
import Link from 'next/link'
import AnimatedSection from '@/components/ui/AnimatedSection'
import PricingSection from '@/components/sections/PricingSection'
import { Lock, Shield, UserCheck, ArrowRight, Building2, CheckCircle2 } from 'lucide-react'
import { images } from '@/lib/utils'

export const metadata: Metadata = {
  title: 'Join Care Access Nigeria — Become a Member',
  description:
    'Join Care Access Nigeria and get a dedicated personal doctor, 24/7 clinical advice, and expert care coordination. Plans from ₦25,000/month. No lock-in, cancel anytime.',
  alternates: { canonical: 'https://careaccess.ng/become-a-member' },
  openGraph: {
    title: 'Join Care Access Nigeria',
    description: 'Personal doctor + 24/7 clinical advice. Plans from ₦25,000/month. No lock-in.',
    url: 'https://careaccess.ng/become-a-member',
  },
  twitter: {
    title: 'Join Care Access Nigeria',
    description: 'Personal doctor + 24/7 clinical advice. From ₦25,000/month. No lock-in.',
  },
}

const trustSignals = [
  {
    icon: Lock,
    title: 'No lock-in',
    description: 'Cancel before your next billing date. No penalty, no questions asked.',
  },
  {
    icon: Shield,
    title: '100% confidential',
    description: 'Your health data is private, secure, and never shared without your consent.',
  },
  {
    icon: UserCheck,
    title: 'Verified professionals',
    description: 'All doctors and nurses on our team are fully licensed and verified.',
  },
]

export default function BecomeAMemberPage() {
  return (
    <>
      {/* Hero */}
      <section
        className="relative pt-28 pb-16 md:pt-36 md:pb-20 overflow-hidden hero-gradient"
        aria-label="Membership hero"
      >
        <div className="absolute inset-0 bg-navy-mesh" />
        <div className="absolute -top-32 -right-32 w-96 h-96 rounded-full bg-teal/10 blur-3xl" />
        <div className="absolute bottom-0 left-0 right-0">
          <svg viewBox="0 0 1440 60" fill="none" preserveAspectRatio="none">
            <path d="M0 60L1440 60L1440 20C1200 60 900 0 720 0C540 0 240 60 0 20L0 60Z" fill="white" />
          </svg>
        </div>
        <div className="relative z-10 container-max text-center">
          <AnimatedSection>
            <div className="section-tag bg-teal/20 text-teal-200 mx-auto mb-5">Join Care Access</div>
            <h1 className="text-4xl md:text-5xl lg:text-6xl font-extrabold text-white leading-tight mb-5 max-w-3xl mx-auto">
              Join Care Access Nigeria
            </h1>
            <p className="text-base md:text-xl text-white/70 max-w-2xl mx-auto leading-relaxed">
              No queues. No stress. No guesswork. Get continuous access to a trusted medical team
              that understands your history and supports your health every step of the way.
            </p>
          </AnimatedSection>
        </div>
      </section>

      {/* Plan cards + modal (client component) */}
      <PricingSection />

      {/* Non-Member Access */}
      <section className="section-padding bg-white" aria-labelledby="nonmember-heading">
        <div className="container-max">
          <div className="grid lg:grid-cols-2 gap-12 items-center">
            <AnimatedSection animation="fade-right">
              <div className="section-tag bg-orange/10 text-orange mb-4">Non-Member Access</div>
              <h2 id="nonmember-heading" className="text-3xl md:text-4xl font-extrabold text-navy leading-tight mb-5">
                Not a member yet? You can still get help.
              </h2>
              <p className="text-base text-gray-600 leading-relaxed mb-6">
                Non-members can request a consultation by filling out our inquiry form. A nurse or admin will contact you, confirm the cost of the session, and arrange payment before your consultation. Please note: 24/7 clinical advice is exclusively available to subscribed members.
              </p>
              <Link href="/contact" className="btn-primary">
                Request a Consultation <ArrowRight size={16} />
              </Link>
            </AnimatedSection>

            <AnimatedSection animation="fade-left">
              <div className="relative rounded-3xl overflow-hidden aspect-[4/3] shadow-large">
                <Image
                  src={images.femaleNurseOnLaptop}
                  alt="Nurse available for consultation"
                  fill
                  className="object-cover"
                  sizes="50vw"
                />
              </div>
            </AnimatedSection>
          </div>
        </div>
      </section>

      {/* Corporate */}
      <section className="section-padding section-bg-alt" aria-labelledby="corporate-heading">
        <div className="container-max">
          <div className="bg-navy rounded-3xl p-10 md:p-14 grid lg:grid-cols-2 gap-12 items-center">
            <AnimatedSection animation="fade-right">
              <div className="flex items-center gap-3 mb-5">
                <div className="w-12 h-12 rounded-xl bg-teal/20 flex items-center justify-center">
                  <Building2 size={22} className="text-teal-300" />
                </div>
                <span className="text-teal-300 text-xs font-bold uppercase tracking-widest">For Organisations</span>
              </div>
              <h2 id="corporate-heading" className="text-3xl md:text-4xl font-extrabold text-white leading-tight mb-5">
                Healthcare access for your organisation
              </h2>
              <p className="text-white/70 leading-relaxed mb-8">
                We offer tailored healthcare access packages for businesses, NGOs, and corporate teams. Give your employees guided care support, teleconsultation, and 24/7 clinical advice as part of their benefits package. Healthier teams are more productive, more present, and more loyal.
              </p>
              <div className="space-y-3 mb-8">
                {[
                  'Scalable plans for any team size',
                  'Dedicated account management',
                  'Employee wellness reporting',
                  'Custom onboarding for your team',
                ].map((item) => (
                  <div key={item} className="flex items-center gap-2.5 text-sm text-white/70">
                    <CheckCircle2 size={15} className="text-teal-300 flex-shrink-0" />
                    {item}
                  </div>
                ))}
              </div>
              <Link
                href="/contact"
                className="inline-flex items-center gap-2 px-6 py-3.5 bg-teal text-white rounded-xl font-semibold text-sm hover:bg-teal-600 transition-all duration-200"
              >
                Partner With Us <ArrowRight size={16} />
              </Link>
            </AnimatedSection>

            <AnimatedSection animation="fade-left">
              <div className="relative rounded-2xl overflow-hidden aspect-[4/3] shadow-large">
                <Image
                  src={images.doctorVideoCall}
                  alt="Corporate healthcare partnership"
                  fill
                  className="object-cover"
                  sizes="50vw"
                />
              </div>
            </AnimatedSection>
          </div>
        </div>
      </section>

      {/* Trust signals */}
      <section className="py-16 bg-white" aria-label="Trust signals">
        <div className="container-max">
          <div className="grid md:grid-cols-3 gap-6">
            {trustSignals.map(({ icon: Icon, title, description }, i) => (
              <AnimatedSection key={title} delay={i * 100} animation="fade-up">
                <div className="flex gap-4 p-6 rounded-2xl bg-gray-50 border border-gray-100">
                  <div className="w-10 h-10 rounded-xl bg-teal/10 flex items-center justify-center flex-shrink-0">
                    <Icon size={18} className="text-teal" />
                  </div>
                  <div>
                    <h3 className="font-bold text-navy mb-1 text-sm">{title}</h3>
                    <p className="text-xs text-gray-500 leading-relaxed">{description}</p>
                  </div>
                </div>
              </AnimatedSection>
            ))}
          </div>
        </div>
      </section>
    </>
  )
}
