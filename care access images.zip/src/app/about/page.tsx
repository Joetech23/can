import type { Metadata } from 'next'
import Image from 'next/image'
import Link from 'next/link'
import AnimatedSection from '@/components/ui/AnimatedSection'
import { images } from '@/lib/utils'
import { Target, Eye, Heart, Users, Building2, Shield, CheckCircle2, ArrowRight, Stethoscope, GitBranch } from 'lucide-react'
// Team section removed — not ready for public display

export const metadata: Metadata = {
  title: 'About Us',
  description:
    'Learn the story behind Care Access Nigeria. We exist to make healthcare personal again — giving every Nigerian a dedicated personal doctor and expert care coordination.',
  alternates: {
    canonical: 'https://careaccess.ng/about',
  },
}

const values = [
  {
    icon: Heart,
    title: 'People First',
    description: 'Every decision we make is measured by one question: does this make life better for our members?',
    color: 'text-orange',
    bg: 'bg-orange/10',
  },
  {
    icon: Shield,
    title: 'Trust & Transparency',
    description: 'We tell you exactly what we can do, what we cannot do, and why. No medical jargon, no guessing.',
    color: 'text-navy',
    bg: 'bg-navy/10',
  },
  {
    icon: Users,
    title: 'Continuity of Care',
    description: 'We believe in lasting relationships, not one-off interactions. Your doctor remembers you.',
    color: 'text-teal',
    bg: 'bg-teal/10',
  },
  {
    icon: Building2,
    title: 'Trusted Network',
    description: 'We partner only with vetted hospitals, labs, pharmacies, and ambulance services across Nigeria.',
    color: 'text-green',
    bg: 'bg-green/10',
  },
]

const approach = [
  {
    icon: Stethoscope,
    title: 'Your personal doctor',
    description: 'A permanent in-house doctor who tracks your health over time, manages your family profile, and is your first point of contact for everything medical. You never explain your history to a stranger.',
  },
  {
    icon: GitBranch,
    title: 'Coordinated specialist referrals',
    description: 'When you need a specialist, your doctor evaluates you first and connects you directly to a vetted in-house specialist. No guessing, no waiting rooms full of strangers who know nothing about you.',
  },
  {
    icon: Building2,
    title: 'A trusted network',
    description: 'Partner hospitals, labs, pharmacies, and ambulances that receive your records (with your full consent) so your care is never fragmented. You arrive expected, not unknown.',
  },
]

export default function AboutPage() {
  return (
    <>
      {/* Page hero */}
      <section className="relative pt-28 pb-20 md:pt-36 md:pb-28 overflow-hidden hero-gradient" aria-label="About hero">
        <div className="absolute inset-0 bg-navy-mesh" />
        <div className="absolute bottom-0 left-0 right-0">
          <svg viewBox="0 0 1440 60" fill="none" xmlns="http://www.w3.org/2000/svg" preserveAspectRatio="none">
            <path d="M0 60L1440 60L1440 20C1200 60 900 0 720 0C540 0 240 60 0 20L0 60Z" fill="white" />
          </svg>
        </div>
        <div className="relative z-10 container-max text-center">
          <AnimatedSection>
            <div className="section-tag bg-teal/20 text-teal-200 mx-auto mb-5">
              Our Story
            </div>
            <h1 className="text-4xl md:text-5xl lg:text-6xl font-extrabold text-white leading-tight mb-6 max-w-4xl mx-auto">
              We exist to make healthcare{' '}
              <span className="text-teal-300">personal again</span>
            </h1>
            <p className="text-base md:text-xl text-white/70 max-w-2xl mx-auto leading-relaxed">
              Care Access Nigeria was built to solve a real problem: the gap between needing care and actually getting the right care.
            </p>
          </AnimatedSection>
        </div>
      </section>

      {/* Who We Are */}
      <section className="section-padding bg-white" aria-labelledby="who-heading">
        <div className="container-max">
          <div className="grid lg:grid-cols-2 gap-16 items-center">
            <AnimatedSection animation="fade-right">
              <div className="relative rounded-3xl overflow-hidden aspect-[4/5] shadow-large">
                <Image
                  src={images.aboutUsPicture}
                  alt="Care Access Nigeria — personal healthcare"
                  fill
                  className="object-cover"
                  sizes="50vw"
                />
                <div className="absolute inset-0 bg-gradient-to-t from-navy/40 to-transparent" />
              </div>
            </AnimatedSection>

            <AnimatedSection animation="fade-left">
              <div className="section-tag bg-teal/10 text-teal mb-4">Who We Are</div>
              <h2 id="who-heading" className="text-3xl md:text-4xl font-extrabold text-navy leading-tight mb-6">
                Built to solve a real problem
              </h2>
              <div className="space-y-4 text-base text-gray-600 leading-relaxed">
                <p>
                  In Nigeria, accessing the right healthcare can often feel overwhelming.
                  Long waiting times, crowded facilities, and fragmented care mean many people
                  never get the guidance they truly need. In that uncertainty, it’s common for
                  people to turn to a pharmacy and self-medicate—choosing treatments without
                  proper medical advice. This happens every day, and it carries real risks.
                </p>
                <p>
                  Care Access Nigeria was created to offer a better way. We provide direct, ongoing
                  access to a trusted medical team that understands your health history and supports
                  you over time. Every consultation builds on a complete medical record, giving you
                  consistent, informed care whenever you need it. From everyday concerns to long-term
                  conditions, we guide your treatment, coordinate your care, and help you make the
                  right decisions for your health.
                </p>
                <p>
                  We also support your household, with shared health records and continuity of care
                  for your family—ensuring that important medical information is always known and
                  considered.
                </p>
                <p>
                  We are not a hospital. We are your first point of contact, your guide through the
                  healthcare system, and your partner in managing your health—clearly, calmly, and
                  consistently.
                </p>
              </div>

              <div className="flex flex-col sm:flex-row gap-4 mt-8">
                <Link href="/become-a-member" className="btn-primary">
                  Become a Member <ArrowRight size={16} />
                </Link>
                <Link href="/services" className="btn-secondary">
                  Explore Services
                </Link>
              </div>
            </AnimatedSection>
          </div>
        </div>
      </section>

      {/* Mission & Vision */}
      <section className="section-padding section-bg-alt" aria-label="Mission and vision">
        <div className="container-max">
          <AnimatedSection className="text-center mb-14">
            <div className="section-tag bg-navy/10 text-navy mx-auto mb-4">Our Purpose</div>
            <h2 className="text-3xl md:text-4xl font-extrabold text-navy mb-4">
              What drives everything we do
            </h2>
          </AnimatedSection>

          <div className="grid md:grid-cols-2 gap-8">
            <AnimatedSection delay={100} animation="fade-up">
              <div className="bg-navy rounded-3xl p-8 md:p-10 text-white h-full">
                <div className="w-14 h-14 rounded-2xl bg-white/15 flex items-center justify-center mb-6">
                  <Target size={26} className="text-teal-300" />
                </div>
                <div className="text-teal-300 text-xs font-bold uppercase tracking-widest mb-3">Our Mission</div>
                <h3 className="text-2xl font-extrabold mb-4 leading-tight">
                  Healthcare for every Nigerian, transparently and equally
                </h3>
                <p className="text-white/70 leading-relaxed">
                  To redefine how healthcare is experienced in Nigeria making it accessible, transparent, and dependable for everyone.
Through continuous care, personalised guidance, and trusted clinical support, we ensure every patient receives the attention and direction they deserve.
                </p>
              </div>
            </AnimatedSection>

            <AnimatedSection delay={200} animation="fade-up">
              <div className="bg-teal rounded-3xl p-8 md:p-10 text-white h-full">
                <div className="w-14 h-14 rounded-2xl bg-white/15 flex items-center justify-center mb-6">
                  <Eye size={26} className="text-white" />
                </div>
                <div className="text-white/70 text-xs font-bold uppercase tracking-widest mb-3">Our Vision</div>
                <h3 className="text-2xl font-extrabold mb-4 leading-tight">
                  Expert-guided healthcare for every person, everywhere
                </h3>
                <p className="text-white/70 leading-relaxed">
                  To make trusted, continuous healthcare accessible to every person in Nigeria, regardless of location, income, or circumstance, through a care model that treats each patient as a whole person, not a one-off case.
                </p>
              </div>
            </AnimatedSection>
          </div>
        </div>
      </section>

      {/* Our Approach */}
      {/* <section className="section-padding bg-white" aria-labelledby="approach-heading">
        <div className="container-max">
          <AnimatedSection className="text-center mb-14">
            <div className="section-tag bg-teal/10 text-teal mx-auto mb-4">How We Work</div>
            <h2 id="approach-heading" className="text-3xl md:text-4xl font-extrabold text-navy mb-4">
              Continuity of care, not one-off consultations
            </h2>
            <p className="text-base text-gray-500 max-w-xl mx-auto">
              Our approach to healthcare is built on three interconnected pillars that work together to give you complete, continuous coverage.
            </p>
          </AnimatedSection>

          <div className="grid md:grid-cols-3 gap-8">
            {approach.map(({ icon: Icon, title, description }, i) => (
              <AnimatedSection key={title} delay={i * 120} animation="fade-up">
                <div className="relative">
                  <div className="text-8xl font-black text-gray-50 select-none absolute -top-4 -left-2">
                    {String(i + 1).padStart(2, '0')}
                  </div>
                  <div className="relative pt-4">
                    <div className="w-12 h-12 rounded-xl bg-teal/10 flex items-center justify-center mb-4">
                      <Icon size={22} className="text-teal" />
                    </div>
                    <h3 className="text-lg font-bold text-navy mb-3">{title}</h3>
                    <p className="text-sm text-gray-600 leading-relaxed">{description}</p>
                  </div>
                </div>
              </AnimatedSection>
            ))}
          </div>
        </div>
      </section> */}

      {/* Values */}
      <section className="section-padding section-bg-alt" aria-labelledby="values-heading">
        <div className="container-max">
          <AnimatedSection className="text-center mb-14">
            <div className="section-tag bg-orange/10 text-orange mx-auto mb-4">What We Stand For</div>
            <h2 id="values-heading" className="text-3xl md:text-4xl font-extrabold text-navy mb-4">
              The principles behind our care
            </h2>
          </AnimatedSection>

          <div className="grid sm:grid-cols-2 lg:grid-cols-4 gap-6">
            {values.map(({ icon: Icon, title, description, color, bg }, i) => (
              <AnimatedSection key={title} delay={i * 100} animation="fade-up">
                <div className="card text-center">
                  <div className={`w-14 h-14 rounded-2xl ${bg} flex items-center justify-center mx-auto mb-4`}>
                    <Icon size={24} className={color} />
                  </div>
                  <h3 className="font-bold text-navy mb-2">{title}</h3>
                  <p className="text-sm text-gray-500 leading-relaxed">{description}</p>
                </div>
              </AnimatedSection>
            ))}
          </div>
        </div>
      </section>

      {/* Difference Banner */}
      <section className="relative py-20 overflow-hidden" aria-label="What makes us different">
        <div className="absolute inset-0 bg-navy" />
        <div className="absolute inset-0 bg-navy-mesh" />
        <div className="relative z-10 container-max">
          <div className="grid lg:grid-cols-2 gap-12 items-center">
            <AnimatedSection animation="fade-right">
              <div className="relative rounded-3xl overflow-hidden aspect-[4/3]">
                <Image
                  src={images.ourDifferencePicture}
                  alt="What makes Care Access Nigeria different"
                  fill
                  className="object-cover"
                  sizes="50vw"
                />
                <div className="absolute inset-0 bg-teal/20" />
              </div>
            </AnimatedSection>
            <AnimatedSection animation="fade-left">
              <div className="section-tag bg-white/10 text-teal-300 mb-5">Our Difference</div>
                <h2 className="text-3xl md:text-4xl font-extrabold text-white leading-tight mb-6">
                More than a telemedicine app
                </h2>
                <p className="text-white/80 text-base md:text-lg leading-relaxed mb-6">
                Care Access Nigeria is built around continuous, connected care not one-off consultations.
                </p>
                <div className="space-y-4">
                {[
                  'A dedicated care team that understands your history',
                  'Support for you and your household',
                  'Guided referrals, not guesswork',
                  'Seamless, coordinated care',
                  'Care that continues over time',
                ].map((item) => (
                  <div key={item} className="flex items-start gap-3">
                  <CheckCircle2 size={18} className="text-teal-300 flex-shrink-0 mt-0.5" />
                  <span className="text-white/80 text-sm md:text-base">{item}</span>
                  </div>
                ))}
                </div>
              <div className="flex gap-4 mt-8">
                <Link href="/become-a-member" className="btn-primary">
                  Join Care Access
                </Link>
              </div>
            </AnimatedSection>
          </div>
        </div>
      </section>
    </>
  )
}
