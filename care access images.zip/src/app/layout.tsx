import type { Metadata, Viewport } from 'next'
import './globals.css'
import Navbar from '@/components/layout/Navbar'
import Footer from '@/components/layout/Footer'
import WhatsAppButton from '@/components/layout/WhatsAppButton'

export const metadata: Metadata = {
  metadataBase: new URL('https://careaccess.ng'),
  title: {
    default: 'Care Access Nigeria | Your Personal Doctor, Always Within Reach',
    template: '%s | Care Access Nigeria',
  },
  description:
    'Care Access Nigeria gives every member a dedicated personal doctor who knows their medical history, 24/7 nurse access, teleconsultation, home visits, and full care coordination. Healthcare made personal.',
  keywords: [
    'personal doctor Nigeria',
    'telemedicine Nigeria',
    'virtual clinic Nigeria',
    'healthcare Nigeria',
    'teleconsultation',
    '24/7 nurse',
    'health membership Nigeria',
    'family doctor Nigeria',
    'care access Nigeria',
    'online doctor Nigeria',
  ],
  authors: [{ name: 'Care Access Nigeria' }],
  creator: 'Care Access Nigeria',
  publisher: 'Care Access Nigeria',
  openGraph: {
    type: 'website',
    locale: 'en_NG',
    url: 'https://careaccess.ng',
    siteName: 'Care Access Nigeria',
    title: 'Care Access Nigeria | Your Personal Doctor, Always Within Reach',
    description:
      'A dedicated personal doctor, 24/7 nurse access, and expert care coordination — for individuals, families, and organisations across Nigeria.',
    images: [
      {
        url: 'https://res.cloudinary.com/dx2bbdxnw/image/upload/v1776377034/doctor_with_families_vjxq4i.jpg',
        width: 1200,
        height: 630,
        alt: 'Care Access Nigeria',
      },
    ],
  },
  twitter: {
    card: 'summary_large_image',
    title: 'Care Access Nigeria | Your Personal Doctor, Always Within Reach',
    description:
      'Get a dedicated personal doctor, 24/7 nurse access, and expert care coordination.',
    images: ['https://res.cloudinary.com/dx2bbdxnw/image/upload/v1776377034/doctor_with_families_vjxq4i.jpg'],
  },
  robots: {
    index: true,
    follow: true,
    googleBot: {
      index: true,
      follow: true,
      'max-video-preview': -1,
      'max-image-preview': 'large',
      'max-snippet': -1,
    },
  },
  verification: {
    google: 'your-google-verification-code',
  },
  alternates: {
    canonical: 'https://careaccess.ng',
  },
}

export const viewport: Viewport = {
  width: 'device-width',
  initialScale: 1,
  maximumScale: 5,
  themeColor: '#014381',
}

export default function RootLayout({
  children,
}: Readonly<{
  children: React.ReactNode
}>) {
  return (
    <html lang="en-NG" className="scroll-smooth">
      <head>
        <link rel="preconnect" href="https://fonts.googleapis.com" />
        <link rel="preconnect" href="https://fonts.gstatic.com" crossOrigin="anonymous" />
        <link
          href="https://fonts.googleapis.com/css2?family=Marcellus&display=swap"
          rel="stylesheet"
        />
        <link rel="icon" href="/favicon.ico" />
        <link rel="apple-touch-icon" href="/apple-touch-icon.png" />
        <script
          type="application/ld+json"
          dangerouslySetInnerHTML={{
            __html: JSON.stringify({
              '@context': 'https://schema.org',
              '@type': 'MedicalOrganization',
              name: 'Care Access Nigeria',
              url: 'https://careaccess.ng',
              logo: 'https://careaccess.ng/logo.png',
              description:
                'Care Access Nigeria is a virtual clinic providing dedicated personal doctors, 24/7 nurse access, teleconsultation, home visits, and care coordination.',
              contactPoint: {
                '@type': 'ContactPoint',
                email: 'info@careaccess.ng',
                contactType: 'customer service',
                availableLanguage: 'English',
              },
              areaServed: 'NG',
              medicalSpecialty: 'General Practice',
            }),
          }}
        />
      </head>
      <body className="antialiased">
        <Navbar />
        <main>{children}</main>
        <Footer />
        <WhatsAppButton />
      </body>
    </html>
  )
}
